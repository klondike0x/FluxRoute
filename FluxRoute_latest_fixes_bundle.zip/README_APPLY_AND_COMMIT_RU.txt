FluxRoute - актуальный пакет исправлений

Внутри этого архива собраны последние исправления из чата:

1) Улучшенная проверка профилей:
   - проверка через curl.exe;
   - параллельная проверка целей;
   - weighted score;
   - проверка winws.exe;
   - защита от ложных переключений;
   - прямой запуск winws.exe дочерним процессом FluxRoute, если BAT можно разобрать.

2) TG WS Proxy:
   - поле Secret возвращено;
   - поле "Домен Fake-TLS (SNI)" удаляется из MainWindow.xaml скриптом;
   - --fake-tls-domain больше не передается;
   - Telegram-ссылка формируется обычным dd-secret.

Как применить:

1. Закрой FluxRoute и Visual Studio.
2. Распакуй архив в корень репозитория, где лежит FluxRoute.slnx, с заменой файлов.
3. Запусти PowerShell в корне репозитория и выполни:

   powershell -ExecutionPolicy Bypass -File .\apply_restore_tg_secret.ps1

4. Удали папки сборки:

   Remove-Item .\FluxRoute\bin -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item .\FluxRoute\obj -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item .\FluxRoute.Core\bin -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item .\FluxRoute.Core\obj -Recurse -Force -ErrorAction SilentlyContinue

5. Открой решение и сделай Clean Solution -> Rebuild Solution.

Как отправить на GitHub:

   git status --short
   git add FluxRoute.Core/Models/CheckResult.cs
   git add FluxRoute.Core/Models/ProfileProbeOptions.cs
   git add FluxRoute.Core/Models/ProfileProbeResult.cs
   git add FluxRoute.Core/Models/ProfileScore.cs
   git add FluxRoute.Core/Services/ConnectivityChecker.cs
   git add FluxRoute.Core/Services/ProcessHealthChecker.cs
   git add FluxRoute.Core/Services/ProfileScoringService.cs
   git add FluxRoute.Core/Services/ProfileProbeService.cs
   git add FluxRoute.Core/Services/OrchestratorService.cs
   git add FluxRoute.Core/Services/ProfileBatLauncher.cs
   git add FluxRoute/ViewModels/MainViewModel.Orchestrator.cs
   git add FluxRoute/ViewModels/MainViewModel.Process.cs
   git add FluxRoute/ViewModels/MainViewModel.TgProxy.cs
   git add FluxRoute/Views/MainWindow.xaml.cs
   git add FluxRoute/Views/MainWindow.xaml
   git commit -m "Improve profile checks and fix TG proxy fields"
   git push origin master

Если git status --short ничего не показывает после распаковки — значит архив распакован не в тот проект/не в ту копию репозитория.
