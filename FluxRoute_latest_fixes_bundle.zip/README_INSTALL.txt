FluxRoute profile probe patch v4 — curl + parallel check + direct winws child process

Куда распаковывать:
  Распакуйте архив в корень репозитория FluxRoute с заменой файлов.
  Это папка, где лежит FluxRoute.slnx.

Файлы:
  FluxRoute.Core/Models/CheckResult.cs
  FluxRoute.Core/Models/ProfileProbeOptions.cs
  FluxRoute.Core/Models/ProfileProbeResult.cs
  FluxRoute.Core/Models/ProfileScore.cs

  FluxRoute.Core/Services/ConnectivityChecker.cs
  FluxRoute.Core/Services/ProcessHealthChecker.cs
  FluxRoute.Core/Services/ProfileScoringService.cs
  FluxRoute.Core/Services/ProfileProbeService.cs
  FluxRoute.Core/Services/ProfileBatLauncher.cs
  FluxRoute.Core/Services/OrchestratorService.cs

  FluxRoute/ViewModels/MainViewModel.Orchestrator.cs
  FluxRoute/ViewModels/MainViewModel.Process.cs

Что нового в v4:
  1. HTTP-проверки профилей идут через curl.exe и параллельно.
  2. FluxRoute больше не запускает профиль только как cmd.exe /c profile.bat.
  3. Новый ProfileBatLauncher читает BAT-профиль, вытаскивает команду winws.exe и запускает winws.exe напрямую из FluxRoute.
  4. В Process Explorer / Process Hacker winws.exe должен отображаться как дочерний процесс FluxRoute.exe.
  5. Если BAT нестандартный и разобрать его не удалось, FluxRoute автоматически вернётся к старому совместимому запуску через BAT/cmd.exe.
  6. В прямом режиме кнопка Stop убивает только winws.exe, запущенный FluxRoute, а не все winws.exe в системе.

После распаковки:
  1. Откройте решение в Visual Studio.
  2. Выполните Rebuild Solution.
  3. Запустите FluxRoute от имени администратора.
  4. Запустите профиль и проверьте дерево процессов.

Если будут ошибки сборки:
  Пришлите первые 10 ошибок из Error List. Лучше отсортировать по File/Line.
